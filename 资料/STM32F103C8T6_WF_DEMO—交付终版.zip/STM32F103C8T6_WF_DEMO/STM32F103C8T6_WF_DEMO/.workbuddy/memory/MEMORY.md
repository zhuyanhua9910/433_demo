# 项目长期记忆（STM32F103C8T6_TX / Wf4463 433MHz）

## 硬件
- MCU：STM32F103C8T6（64MHz，HWF+PLL×16，无外部晶振）
- 射频：Wf4463 裸模块（无 RF 开关），Rev **C2**（PART=0x4463，CHIPREV=0x22），晶振 **30MHz**
- 频段：433MHz 段（WDS 配置 433MHz / 10kbps / FSK / 20kHz 频偏）

## 引脚
| 功能 | 引脚 |
|---|---|
| SPI2 SCK / MISO / MOWF | PB13 / PB14 / PB15 |
| nSEL (CS) | PB12（输出，初值高） |
| SDN | PB1（输出，初值低=工作） |
| nIRQ | PB10（上拉输入；低=有中断） |
| 调试串口 USART1 | PA9 / PA10（115200） |
| 角色选择 CHOOSE_MODE | PA2（输入+上拉；高=TX，低=RX） |

## 软件方案（已定型）
- 使用 Wflicon Labs **官方 Wf446x API 库**（Core/Wf4464，来自参考工程），不再使用 Borchevkin 驱动（已移至 legacy_driver_backup/）。
- 应用层：`wf4463_init()` / `wf4463_tx()` / `wf4463_rx_start()` / `wf4463_rx_fetch()` / `wf4463_diag()`。
- 角色选择：运行时读 `CHOOSE_MODE` 引脚电平（main.h 宏），**高=发送端、低=接收端**，仅上电检测一次；同一固件两端通用，不再分开编译。
- 业务载荷：文本 `"WF HELLO %03u"`（12 字节），500ms 一包。
- 日志：`TX #n > "..."`、`RX #n < "..." | len rswf`。

## 已修复的库缺陷（勿回退）
1. `wf4463_wait_irq()` 与 TX 等待循环 nIRQ 极性写反（低=有中断），已改为 `if (wf4463_irq_asserted())`。
2. `wf4463_rx_fetch()` 误把 RX FIFO 首字节当长度字节跳过（变长模式下长度字节不写入 FIFO），已改为从 `tmp[0]` 拷 `count` 字节。
3. `wf4463_tx()` 改为 SPI 轮询 `GET_INT_STATUS` 的 `PH_PEND.PACKET_SENT` 判定发送完成，不依赖 nIRQ。
4. `wf4463_rx_start()` 参数全 0，收完包芯片回 READY，应用层必须重新调用 `wf4463_rx_start()`。

## 注意事项
- SPI 现为 1Mbps（APB1 32MHz /32）；Wf4463 上限 10MHz，长读 FIFO 时高速易位偏移。
- 两板间距建议 1~2m，过近（rswf > -25dBm）可能过载。
