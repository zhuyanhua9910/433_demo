/*!
 * File:
 *  wf446x_api_lib.c
 *
 * Description:
 *  This file contains the Wf446x API library.
 *
 * Silicon Laboratories Confidential
 * Copyright 2011 Silicon Laboratories, Inc.
 */

#include "compiler_defs.h"
#include "wf446x_defs.h"
#include "wf446x_api_lib.h"
#include "radio_comm.h"
#include "radio_hal.h"



#include <stdarg.h>

union wf446x_cmd_reply_union Wf446xCmd;
U8 Pro2Cmd[16];

#ifdef WF446X_PATCH_CMDS
const U8 Wf446xPatchCommands[][8] = { WF446X_PATCH_CMDS };
#endif


/*!
 * This functions is used to reset the wf446x radio by applying shutdown and
 * releasing it.  After this function @ref wf446x_boot should be called.  You
 * can check if POR has completed by waiting 4 ms or by polling GPIO 0, 2, or 3.
 * When these GPIOs are high, it is safe to call @ref wf446x_boot.
 */
void wf446x_reset(void)
{
    U8 loopCount;

    /* Put radio in shutdown, wait then release */
    radio_hal_AssertShutdown();
    //! @todo this needs to be a better delay function.
    for (loopCount = 255; loopCount != 0; loopCount--);
    radio_hal_DeassertShutdown();
    for (loopCount = 255; loopCount != 0; loopCount--);
    radio_comm_ClearCTS();
}

/*!
 * This function is used to initialize after power-up the radio chip.
 * Before this function @wf446x_reset should be called.
 */
void wf446x_power_up(U8 BOOT_OPTIONS, U8 XTAL_OPTIONS, U32 XO_FREQ)
{
    Pro2Cmd[0] = WF446X_CMD_ID_POWER_UP;
    Pro2Cmd[1] = BOOT_OPTIONS;
    Pro2Cmd[2] = XTAL_OPTIONS;
    Pro2Cmd[3] = (U8)(XO_FREQ >> 24);
    Pro2Cmd[4] = (U8)(XO_FREQ >> 16);
    Pro2Cmd[5] = (U8)(XO_FREQ >> 8);
    Pro2Cmd[6] = (U8)(XO_FREQ);

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_POWER_UP, Pro2Cmd );
}

/*!
 * This function is used to load all properties and commands with a list of NULL terminated commands.
 * Before this function @wf446x_reset should be called.
 */
U8 wf446x_configuration_init(const U8* pSetPropCmd)
{
  U8 col;
  U8 numOfBytes;

  /* While cycle as far as the pointer points to a command */
  while (*pSetPropCmd != 0x00)
  {
    /* Commands structure in the array:
     * --------------------------------
     * LEN | <LEN length of data>
     */

    numOfBytes = *pSetPropCmd++;

    if (numOfBytes > 16u)
    {
      /* Number of command bytes exceeds maximal allowable length */
      return WF446X_COMMAND_ERROR;
    }

    for (col = 0u; col < numOfBytes; col++)
    {
      Pro2Cmd[col] = *pSetPropCmd;
      pSetPropCmd++;
    }

    if (radio_comm_SendCmdGetResp(numOfBytes, Pro2Cmd, 0, 0) != 0xFF)
    {
      /* Timeout occured */
      return WF446X_CTS_TIMEOUT;
    }

    if (radio_hal_NirqLevel() == 0)
    {
      /* Get and clear all interrupts.  An error has occured... */
      wf446x_get_int_status(0, 0, 0);
      if (Wf446xCmd.GET_INT_STATUS.CHIP_PEND & WF446X_CMD_GET_CHIP_STATUS_REP_CMD_ERROR_PEND_MASK)
      {
        return WF446X_COMMAND_ERROR;
      }
    }
  }

  return WF446X_SUCCESS;
}

/*!
 * This function is used to apply a firmware patch to the wf446x radio.  This
 * patch is stored in code using the wf446x_patch.h file.
 *
 * @return  WF446X_CTS_TIMEOUT If a CTS error occurs.
 *          WF446X_PATCH_FAIL If the patch fails.
 *          WF446X_SUCCESS If the patch is successful.
 *          WF446X_NO_PATCH If there is no patch in the Flash to load.
 */
U8 wf446x_apply_patch(void)
{
#ifdef WF446X_PATCH_CMDS
    SEGMENT_VARIABLE(line, U16, SEG_DATA);
    SEGMENT_VARIABLE(row,  U8, SEG_DATA);

    /* Check if patch is needed. */
    wf446x_part_info();

    if ((Wf446xCmd.PART_INFO.ROMID == WF446X_PATCH_ROMID) && (Wf446xCmd.PART_INFO.ID.U8[MSB] < WF446X_PATCH_ID))
    {
      for (line = 0; line < (sizeof(Wf446xPatchCommands) / 8u); line++)
      {
        for (row=0; row<8; row++)
        {
          Pro2Cmd[row] = Wf446xPatchCommands[line][row];
        }
        if (radio_comm_SendCmdGetResp(8, Pro2Cmd, 0, 0) != 0xFF)
        {
          // Timeout occured
          return WF446X_CTS_TIMEOUT;
        }
        if (radio_hal_NirqLevel() == 0)
        {
          /* Get and clear all interrupts.  An error has occured... */
          wf446x_get_int_status(0, 0, 0);
          return WF446X_PATCH_FAIL;
        }
      }
    }

    return WF446X_SUCCESS;
#else
    return WF446X_NO_PATCH;
#endif
}

/*! This function sends the PART_INFO command to the radio and receives the answer
 *  into @Wf446xCmd union.
 */
void wf446x_part_info(void)
{
    Pro2Cmd[0] = WF446X_CMD_ID_PART_INFO;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_PART_INFO,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_PART_INFO,
                              Pro2Cmd );

    Wf446xCmd.PART_INFO.CHIPREV         = Pro2Cmd[0];
    Wf446xCmd.PART_INFO.PART.U8[MSB]    = Pro2Cmd[1];
    Wf446xCmd.PART_INFO.PART.U8[LSB]    = Pro2Cmd[2];
    Wf446xCmd.PART_INFO.PBUILD          = Pro2Cmd[3];
    Wf446xCmd.PART_INFO.ID.U8[MSB]      = Pro2Cmd[4];
    Wf446xCmd.PART_INFO.ID.U8[LSB]      = Pro2Cmd[5];
    Wf446xCmd.PART_INFO.CUSTOMER        = Pro2Cmd[6];
    Wf446xCmd.PART_INFO.ROMID           = Pro2Cmd[7];
}

/*! Sends START_TX command to the radio.
 *
 * @param CHANNEL   Channel number.
 * @param CONDITION Start TX condition.
 * @param TX_LEN    Payload length (exclude the PH generated CRC).
 */
void wf446x_start_tx(U8 CHANNEL, U8 CONDITION, U16 TX_LEN)
{
    Pro2Cmd[0] = WF446X_CMD_ID_START_TX;
    Pro2Cmd[1] = CHANNEL;
    Pro2Cmd[2] = CONDITION;
    Pro2Cmd[3] = (U8)(TX_LEN >> 8);
    Pro2Cmd[4] = (U8)(TX_LEN);
    Pro2Cmd[5] = 0x00;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_START_TX, Pro2Cmd );
}

/*!
 * Sends START_RX command to the radio.
 *
 * @param CHANNEL     Channel number.
 * @param CONDITION   Start RX condition.
 * @param RX_LEN      Payload length (exclude the PH generated CRC).
 * @param NEXT_STATE1 Next state when Preamble Timeout occurs.
 * @param NEXT_STATE2 Next state when a valid packet received.
 * @param NEXT_STATE3 Next state when invalid packet received (e.g. CRC error).
 */
void wf446x_start_rx(U8 CHANNEL, U8 CONDITION, U16 RX_LEN, U8 NEXT_STATE1, U8 NEXT_STATE2, U8 NEXT_STATE3)
{
    Pro2Cmd[0] = WF446X_CMD_ID_START_RX;
    Pro2Cmd[1] = CHANNEL;
    Pro2Cmd[2] = CONDITION;
    Pro2Cmd[3] = (U8)(RX_LEN >> 8);
    Pro2Cmd[4] = (U8)(RX_LEN);
    Pro2Cmd[5] = NEXT_STATE1;
    Pro2Cmd[6] = NEXT_STATE2;
    Pro2Cmd[7] = NEXT_STATE3;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_START_RX, Pro2Cmd );
}

/*!
 * Get the Interrupt status/pending flags form the radio and clear flags if requested.
 *
 * @param PH_CLR_PEND     Packet Handler pending flags clear.
 * @param MODEM_CLR_PEND  Modem Status pending flags clear.
 * @param CHIP_CLR_PEND   Chip State pending flags clear.
 */
void wf446x_get_int_status(U8 PH_CLR_PEND, U8 MODEM_CLR_PEND, U8 CHIP_CLR_PEND)
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_INT_STATUS;
    Pro2Cmd[1] = PH_CLR_PEND;
    Pro2Cmd[2] = MODEM_CLR_PEND;
    Pro2Cmd[3] = CHIP_CLR_PEND;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_INT_STATUS,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GET_INT_STATUS,
                              Pro2Cmd );

    Wf446xCmd.GET_INT_STATUS.INT_PEND       = Pro2Cmd[0];
    Wf446xCmd.GET_INT_STATUS.INT_STATUS     = Pro2Cmd[1];
    Wf446xCmd.GET_INT_STATUS.PH_PEND        = Pro2Cmd[2];
    Wf446xCmd.GET_INT_STATUS.PH_STATUS      = Pro2Cmd[3];
    Wf446xCmd.GET_INT_STATUS.MODEM_PEND     = Pro2Cmd[4];
    Wf446xCmd.GET_INT_STATUS.MODEM_STATUS   = Pro2Cmd[5];
    Wf446xCmd.GET_INT_STATUS.CHIP_PEND      = Pro2Cmd[6];
    Wf446xCmd.GET_INT_STATUS.CHIP_STATUS    = Pro2Cmd[7];
}

/*!
 * Send GPIO pin config command to the radio and reads the answer into
 * @Wf446xCmd union.
 *
 * @param GPIO0       GPIO0 configuration.
 * @param GPIO1       GPIO1 configuration.
 * @param GPIO2       GPIO2 configuration.
 * @param GPIO3       GPIO3 configuration.
 * @param NIRQ        NIRQ configuration.
 * @param SDO         SDO configuration.
 * @param GEN_CONFIG  General pin configuration.
 */
void wf446x_gpio_pin_cfg(U8 GPIO0, U8 GPIO1, U8 GPIO2, U8 GPIO3, U8 NIRQ, U8 SDO, U8 GEN_CONFIG)
{
    Pro2Cmd[0] = WF446X_CMD_ID_GPIO_PIN_CFG;
    Pro2Cmd[1] = GPIO0;
    Pro2Cmd[2] = GPIO1;
    Pro2Cmd[3] = GPIO2;
    Pro2Cmd[4] = GPIO3;
    Pro2Cmd[5] = NIRQ;
    Pro2Cmd[6] = SDO;
    Pro2Cmd[7] = GEN_CONFIG;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GPIO_PIN_CFG,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GPIO_PIN_CFG,
                              Pro2Cmd );

    Wf446xCmd.GPIO_PIN_CFG.GPIO0        = Pro2Cmd[0];
    Wf446xCmd.GPIO_PIN_CFG.GPIO1        = Pro2Cmd[1];
    Wf446xCmd.GPIO_PIN_CFG.GPIO2        = Pro2Cmd[2];
    Wf446xCmd.GPIO_PIN_CFG.GPIO3        = Pro2Cmd[3];
    Wf446xCmd.GPIO_PIN_CFG.NIRQ         = Pro2Cmd[4];
    Wf446xCmd.GPIO_PIN_CFG.SDO          = Pro2Cmd[5];
    Wf446xCmd.GPIO_PIN_CFG.GEN_CONFIG   = Pro2Cmd[6];
}

/*!
 * Send SET_PROPERTY command to the radio.
 *
 * @param GROUP       Property group.
 * @param NUM_PROPS   Number of property to be set. The properties must be in ascending order
 *                    in their sub-property aspect. Max. 12 properties can be set in one command.
 * @param START_PROP  Start sub-property address.
 */
#ifdef __C51__
#pragma maxargs (13)  /* allow 13 bytes for parameters */
#endif
void wf446x_set_property( U8 GROUP, U8 NUM_PROPS, U8 START_PROP, ... )
{
    va_list argList;
    U8 cmdIndex;

    Pro2Cmd[0] = WF446X_CMD_ID_SET_PROPERTY;
    Pro2Cmd[1] = GROUP;
    Pro2Cmd[2] = NUM_PROPS;
    Pro2Cmd[3] = START_PROP;

    va_start (argList, START_PROP);
    cmdIndex = 4;
    while(NUM_PROPS--)
    {
        /* C 的默认实参提升会把 U8 提升为 int；按 int 取再截断，避免未定义行为 */
        Pro2Cmd[cmdIndex] = (U8)va_arg (argList, int);
        cmdIndex++;
    }
    va_end(argList);

    radio_comm_SendCmd( cmdIndex, Pro2Cmd );
}

/*!
 * Issue a change state command to the radio.
 *
 * @param NEXT_STATE1 Next state.
 */
void wf446x_change_state(U8 NEXT_STATE1)
{
    Pro2Cmd[0] = WF446X_CMD_ID_CHANGE_STATE;
    Pro2Cmd[1] = NEXT_STATE1;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_CHANGE_STATE, Pro2Cmd );
}


#ifdef RADIO_DRIVER_EXTENDED_SUPPORT
/* Extended driver support functions */
/*!
 * Sends NOP command to the radio. Can be used to maintain SPI communication.
 */
void wf446x_nop(void)
{
    Pro2Cmd[0] = WF446X_CMD_ID_NOP;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_NOP, Pro2Cmd );
}

/*!
 * Send the FIFO_INFO command to the radio. Optionally resets the TX/RX FIFO. Reads the radio response back
 * into @Wf446xCmd.
 *
 * @param FIFO  RX/TX FIFO reset flags.
 */
void wf446x_fifo_info(U8 FIFO)
{
    Pro2Cmd[0] = WF446X_CMD_ID_FIFO_INFO;
    Pro2Cmd[1] = FIFO;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_FIFO_INFO,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_FIFO_INFO,
                              Pro2Cmd );

    Wf446xCmd.FIFO_INFO.RX_FIFO_COUNT   = Pro2Cmd[0];
    Wf446xCmd.FIFO_INFO.TX_FIFO_SPACE   = Pro2Cmd[1];
}

/*!
 * The function can be used to load data into TX FIFO.
 *
 * @param numBytes  Data length to be load.
 * @param pTxData   Pointer to the data (U8*).
 */
void wf446x_write_tx_fifo(U8 numBytes, U8* pTxData)
{
  radio_comm_WriteData( WF446X_CMD_ID_WRITE_TX_FIFO, 0, numBytes, pTxData );
}

/*!
 * Reads the RX FIFO content from the radio.
 *
 * @param numBytes  Data length to be read.
 * @param pRxData   Pointer to the buffer location.
 */
void wf446x_read_rx_fifo(U8 numBytes, U8* pRxData)
{
  radio_comm_ReadData( WF446X_CMD_ID_READ_RX_FIFO, 0, numBytes, pRxData );
}

/*!
 * Get property values from the radio. Reads them into Wf446xCmd union.
 *
 * @param GROUP       Property group number.
 * @param NUM_PROPS   Number of properties to be read.
 * @param START_PROP  Starting sub-property number.
 */
void wf446x_get_property(U8 GROUP, U8 NUM_PROPS, U8 START_PROP)
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_PROPERTY;
    Pro2Cmd[1] = GROUP;
    Pro2Cmd[2] = NUM_PROPS;
    Pro2Cmd[3] = START_PROP;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_PROPERTY,
                              Pro2Cmd,
                              Pro2Cmd[2],
                              Pro2Cmd );

    Wf446xCmd.GET_PROPERTY.DATA0    = Pro2Cmd[0];
    Wf446xCmd.GET_PROPERTY.DATA1    = Pro2Cmd[1];
    Wf446xCmd.GET_PROPERTY.DATA2    = Pro2Cmd[2];
    Wf446xCmd.GET_PROPERTY.DATA3    = Pro2Cmd[3];
    Wf446xCmd.GET_PROPERTY.DATA4    = Pro2Cmd[4];
    Wf446xCmd.GET_PROPERTY.DATA5    = Pro2Cmd[5];
    Wf446xCmd.GET_PROPERTY.DATA6    = Pro2Cmd[6];
    Wf446xCmd.GET_PROPERTY.DATA7    = Pro2Cmd[7];
    Wf446xCmd.GET_PROPERTY.DATA8    = Pro2Cmd[8];
    Wf446xCmd.GET_PROPERTY.DATA9    = Pro2Cmd[9];
    Wf446xCmd.GET_PROPERTY.DATA10   = Pro2Cmd[10];
    Wf446xCmd.GET_PROPERTY.DATA11   = Pro2Cmd[11];
    Wf446xCmd.GET_PROPERTY.DATA12   = Pro2Cmd[12];
    Wf446xCmd.GET_PROPERTY.DATA13   = Pro2Cmd[13];
    Wf446xCmd.GET_PROPERTY.DATA14   = Pro2Cmd[14];
    Wf446xCmd.GET_PROPERTY.DATA15   = Pro2Cmd[15];
}


#ifdef RADIO_DRIVER_FULL_SUPPORT
/* Full driver support functions */

/*!
 * Sends the FUNC_INFO command to the radio, then reads the resonse into @Wf446xCmd union.
 */
void wf446x_func_info(void)
{
    Pro2Cmd[0] = WF446X_CMD_ID_FUNC_INFO;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_FUNC_INFO,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_FUNC_INFO,
                              Pro2Cmd );

    Wf446xCmd.FUNC_INFO.REVEXT          = Pro2Cmd[0];
    Wf446xCmd.FUNC_INFO.REVBRANCH       = Pro2Cmd[1];
    Wf446xCmd.FUNC_INFO.REVINT          = Pro2Cmd[2];
    Wf446xCmd.FUNC_INFO.PATCH.U8[MSB]   = Pro2Cmd[3];
    Wf446xCmd.FUNC_INFO.PATCH.U8[LSB]   = Pro2Cmd[4];
    Wf446xCmd.FUNC_INFO.FUNC            = Pro2Cmd[5];
}

/*!
 * Reads the Fast Response Registers starting with A register into @Wf446xCmd union.
 *
 * @param respByteCount Number of Fast Response Registers to be read.
 */
void wf446x_frr_a_read(U8 respByteCount)
{
    radio_comm_ReadData(WF446X_CMD_ID_FRR_A_READ,
                            0,
                        respByteCount,
                        Pro2Cmd);

    Wf446xCmd.FRR_A_READ.FRR_A_VALUE = Pro2Cmd[0];
    Wf446xCmd.FRR_A_READ.FRR_B_VALUE = Pro2Cmd[1];
    Wf446xCmd.FRR_A_READ.FRR_C_VALUE = Pro2Cmd[2];
    Wf446xCmd.FRR_A_READ.FRR_D_VALUE = Pro2Cmd[3];
}

/*!
 * Reads the Fast Response Registers starting with B register into @Wf446xCmd union.
 *
 * @param respByteCount Number of Fast Response Registers to be read.
 */
void wf446x_frr_b_read(U8 respByteCount)
{
    radio_comm_ReadData(WF446X_CMD_ID_FRR_B_READ,
                            0,
                        respByteCount,
                        Pro2Cmd);

    Wf446xCmd.FRR_B_READ.FRR_B_VALUE = Pro2Cmd[0];
    Wf446xCmd.FRR_B_READ.FRR_C_VALUE = Pro2Cmd[1];
    Wf446xCmd.FRR_B_READ.FRR_D_VALUE = Pro2Cmd[2];
    Wf446xCmd.FRR_B_READ.FRR_A_VALUE = Pro2Cmd[3];
}

/*!
 * Reads the Fast Response Registers starting with C register into @Wf446xCmd union.
 *
 * @param respByteCount Number of Fast Response Registers to be read.
 */
void wf446x_frr_c_read(U8 respByteCount)
{
    radio_comm_ReadData(WF446X_CMD_ID_FRR_C_READ,
                            0,
                        respByteCount,
                        Pro2Cmd);

    Wf446xCmd.FRR_C_READ.FRR_C_VALUE = Pro2Cmd[0];
    Wf446xCmd.FRR_C_READ.FRR_D_VALUE = Pro2Cmd[1];
    Wf446xCmd.FRR_C_READ.FRR_A_VALUE = Pro2Cmd[2];
    Wf446xCmd.FRR_C_READ.FRR_B_VALUE = Pro2Cmd[3];
}

/*!
 * Reads the Fast Response Registers starting with D register into @Wf446xCmd union.
 *
 * @param respByteCount Number of Fast Response Registers to be read.
 */
void wf446x_frr_d_read(U8 respByteCount)
{
    radio_comm_ReadData(WF446X_CMD_ID_FRR_D_READ,
                            0,
                        respByteCount,
                        Pro2Cmd);

    Wf446xCmd.FRR_D_READ.FRR_D_VALUE = Pro2Cmd[0];
    Wf446xCmd.FRR_D_READ.FRR_A_VALUE = Pro2Cmd[1];
    Wf446xCmd.FRR_D_READ.FRR_B_VALUE = Pro2Cmd[2];
    Wf446xCmd.FRR_D_READ.FRR_C_VALUE = Pro2Cmd[3];
}

/*!
 * Reads the ADC values from the radio into @Wf446xCmd union.
 *
 * @param ADC_EN  ADC enable parameter.
 */
void wf446x_get_adc_reading(U8 ADC_EN)
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_ADC_READING;
    Pro2Cmd[1] = ADC_EN;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_ADC_READING,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GET_ADC_READING,
                              Pro2Cmd );

    Wf446xCmd.GET_ADC_READING.GPIO_ADC.U8[MSB]      = Pro2Cmd[0];
    Wf446xCmd.GET_ADC_READING.GPIO_ADC.U8[LSB]      = Pro2Cmd[1];
    Wf446xCmd.GET_ADC_READING.BATTERY_ADC.U8[MSB]   = Pro2Cmd[2];
    Wf446xCmd.GET_ADC_READING.BATTERY_ADC.U8[LSB]   = Pro2Cmd[3];
    Wf446xCmd.GET_ADC_READING.TEMP_ADC.U8[MSB]      = Pro2Cmd[4];
    Wf446xCmd.GET_ADC_READING.TEMP_ADC.U8[LSB]      = Pro2Cmd[5];
    Wf446xCmd.GET_ADC_READING.TEMP_SLOPE            = Pro2Cmd[6];
    Wf446xCmd.GET_ADC_READING.TEMP_INTERCEPT        = Pro2Cmd[7];
}

/*!
 * Receives information from the radio of the current packet. Optionally can be used to modify
 * the Packet Handler properties during packet reception.
 *
 * @param FIELD_NUMBER_MASK Packet Field number mask value.
 * @param LEN               Length value.
 * @param DIFF_LEN          Difference length.
 */
void wf446x_get_packet_info(U8 FIELD_NUMBER_MASK, U16 LEN, S16 DIFF_LEN )
{
    Pro2Cmd[0] = WF446X_CMD_ID_PACKET_INFO;
    Pro2Cmd[1] = FIELD_NUMBER_MASK;
    Pro2Cmd[2] = (U8)(LEN >> 8);
    Pro2Cmd[3] = (U8)(LEN);
    // the different of the byte, although it is signed, but to command handler
    // it can treat it as unsigned
    Pro2Cmd[4] = (U8)((U16)DIFF_LEN >> 8);
    Pro2Cmd[5] = (U8)(DIFF_LEN);

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_PACKET_INFO,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_PACKET_INFO,
                              Pro2Cmd );

    Wf446xCmd.PACKET_INFO.LENGTH_15_8   = Pro2Cmd[0];
    Wf446xCmd.PACKET_INFO.LENGTH_7_0    = Pro2Cmd[1];
}

/*!
 * Gets the Packet Handler status flags. Optionally clears them.
 *
 * @param PH_CLR_PEND Flags to clear.
 */
void wf446x_get_ph_status(U8 PH_CLR_PEND)
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_PH_STATUS;
    Pro2Cmd[1] = PH_CLR_PEND;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_PH_STATUS,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GET_PH_STATUS,
                              Pro2Cmd );

    Wf446xCmd.GET_PH_STATUS.PH_PEND        = Pro2Cmd[0];
    Wf446xCmd.GET_PH_STATUS.PH_STATUS      = Pro2Cmd[1];
}

/*!
 * Gets the Modem status flags. Optionally clears them.
 *
 * @param MODEM_CLR_PEND Flags to clear.
 */
void wf446x_get_modem_status( U8 MODEM_CLR_PEND )
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_MODEM_STATUS;
    Pro2Cmd[1] = MODEM_CLR_PEND;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_MODEM_STATUS,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GET_MODEM_STATUS,
                              Pro2Cmd );

    Wf446xCmd.GET_MODEM_STATUS.MODEM_PEND   = Pro2Cmd[0];
    Wf446xCmd.GET_MODEM_STATUS.MODEM_STATUS = Pro2Cmd[1];
    Wf446xCmd.GET_MODEM_STATUS.CURR_RSSI    = Pro2Cmd[2];
    Wf446xCmd.GET_MODEM_STATUS.LATCH_RSSI   = Pro2Cmd[3];
    Wf446xCmd.GET_MODEM_STATUS.ANT1_RSSI    = Pro2Cmd[4];
    Wf446xCmd.GET_MODEM_STATUS.ANT2_RSSI    = Pro2Cmd[5];
    Wf446xCmd.GET_MODEM_STATUS.AFC_FREQ_OFFSET.U8[MSB]  = Pro2Cmd[6];
    Wf446xCmd.GET_MODEM_STATUS.AFC_FREQ_OFFSET.U8[LSB]  = Pro2Cmd[7];
}

/*!
 * Gets the Chip status flags. Optionally clears them.
 *
 * @param CHIP_CLR_PEND Flags to clear.
 */
void wf446x_get_chip_status( U8 CHIP_CLR_PEND )
{
    Pro2Cmd[0] = WF446X_CMD_ID_GET_CHIP_STATUS;
    Pro2Cmd[1] = CHIP_CLR_PEND;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_GET_CHIP_STATUS,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_GET_CHIP_STATUS,
                              Pro2Cmd );

    Wf446xCmd.GET_CHIP_STATUS.CHIP_PEND         = Pro2Cmd[0];
    Wf446xCmd.GET_CHIP_STATUS.CHIP_STATUS       = Pro2Cmd[1];
    Wf446xCmd.GET_CHIP_STATUS.CMD_ERR_STATUS    = Pro2Cmd[2];
}

/*!
 * Performs image rejection calibration. Completion can be monitored by polling CTS or waiting for CHIP_READY interrupt source.
 *
 * @param SEARCHING_STEP_SIZE
 * @param SEARCHING_RSSI_AVG
 * @param RX_CHAIN_SETTING1
 * @param RX_CHAIN_SETTING2
 */
void wf446x_ircal(U8 SEARCHING_STEP_SIZE, U8 SEARCHING_RSSI_AVG, U8 RX_CHAIN_SETTING1, U8 RX_CHAIN_SETTING2)
{
    Pro2Cmd[0] = WF446X_CMD_ID_IRCAL;
    Pro2Cmd[1] = SEARCHING_STEP_SIZE;
    Pro2Cmd[2] = SEARCHING_RSSI_AVG;
    Pro2Cmd[3] = RX_CHAIN_SETTING1;
    Pro2Cmd[4] = RX_CHAIN_SETTING2;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_IRCAL,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_IRCAL,
                              Pro2Cmd );

    Wf446xCmd.IRCAL.CAL_STATE   = Pro2Cmd[0];
    Wf446xCmd.IRCAL.RSSI        = Pro2Cmd[1];
    Wf446xCmd.IRCAL.DIR_CH      = Pro2Cmd[2];
}

/*!
 * Sets the chip up for specified protocol.
 *
 * @param PROTOCOL    0 = Packet format is generic, no dynamic reprogramming of packet handler properties.
                      1 = Packet format is IEEE802.15.4g compliant. The following properties are overriden:
                      PKT_CRC_CONFIG, CRC_ENDIAN/BIT_ORDER in PKT_CONFG1 for TX and RX, PKT_FIELD_1_CRC_CONFIG for RX.
                      Other applicable properties in the packet handler group still need to be programmed. Field 1 should
                      have the length of 16 bits to contain the PHR with PKT_LEN_FIELD_SOURCE set to 1 for RX. PSDU field
                      shall use Field 2 with variable length. Field 2 length should be set to the maximum allowed including
                      the anticipated FCS length. It is anticipated that the FCS will be calculated by the host and transmitted
                      over the air. Wf4440 will receive PHR and put FCS in the FIFO for the host to retrieve and check.
                      Therefore, CRC shouldn't be enabled on Wf4440.
 */
void wf446x_protocol_cfg(U8 PROTOCOL)
{
    Pro2Cmd[0] = WF446X_CMD_ID_PROTOCOL_CFG;
    Pro2Cmd[1] = PROTOCOL;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_PROTOCOL_CFG, Pro2Cmd );
}

/*!
 * Requests the current state of the device and lists pending TX and RX requests
 */
void wf446x_request_device_state(void)
{
    Pro2Cmd[0] = WF446X_CMD_ID_REQUEST_DEVICE_STATE;

    radio_comm_SendCmdGetResp( WF446X_CMD_ARG_COUNT_REQUEST_DEVICE_STATE,
                              Pro2Cmd,
                              WF446X_CMD_REPLY_COUNT_REQUEST_DEVICE_STATE,
                              Pro2Cmd );

    Wf446xCmd.REQUEST_DEVICE_STATE.CURR_STATE       = Pro2Cmd[0];
    Wf446xCmd.REQUEST_DEVICE_STATE.CURRENT_CHANNEL  = Pro2Cmd[1];
}

/*!
 * While in RX state this will hop to the frequency specified by the parameters and start searching for a preamble.
 *
 * @param INTE      New INTE register value.
 * @param FRAC2     New FRAC2 register value.
 * @param FRAC1     New FRAC1 register value.
 * @param FRAC0     New FRAC0 register value.
 * @param VCO_CNT1  New VCO_CNT1 register value.
 * @param VCO_CNT0  New VCO_CNT0 register value.
 */
void wf446x_rx_hop(U8 INTE, U8 FRAC2, U8 FRAC1, U8 FRAC0, U8 VCO_CNT1, U8 VCO_CNT0)
{
    Pro2Cmd[0] = WF446X_CMD_ID_RX_HOP;
    Pro2Cmd[1] = INTE;
    Pro2Cmd[2] = FRAC2;
    Pro2Cmd[3] = FRAC1;
    Pro2Cmd[4] = FRAC0;
    Pro2Cmd[5] = VCO_CNT1;
    Pro2Cmd[6] = VCO_CNT0;

    radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_RX_HOP, Pro2Cmd );
}

/*!
 * This command is used to allow override of the AGC.
 *
 * @param AGC_OVERRIDE  AGC override parameters.
 */
void wf446x_agc_override(U8 AGC_OVERRIDE)
{
  Pro2Cmd[0] = WF446X_CMD_ID_AGC_OVERRIDE;
  Pro2Cmd[1] = AGC_OVERRIDE;

  radio_comm_SendCmd( WF446X_CMD_ARG_COUNT_AGC_OVERRIDE, Pro2Cmd );
}

#endif /* RADIO_DRIVER_FULL_SUPPORT */
void reConfigPktHandler(void)
{
  Pro2Cmd[0] = 0x11;
  Pro2Cmd[1] = 0x12;
  Pro2Cmd[2] = 0x0C;
  Pro2Cmd[3] = 0x08;
  Pro2Cmd[4] = 0x22;
  Pro2Cmd[5] = 0x01;
  Pro2Cmd[6] = 0x00;
  Pro2Cmd[7] = 0x30;
  Pro2Cmd[8] = 0x30;
  Pro2Cmd[9] = 0x00;
  Pro2Cmd[10] = 0x01;
  Pro2Cmd[11] = 0x04;
  Pro2Cmd[12] = 0x80;
  Pro2Cmd[13] = 0x1F;
  Pro2Cmd[14] = 0xFF;
  Pro2Cmd[15] = 0x00;


  radio_comm_SendCmd( 0x10, Pro2Cmd );
}


#endif /* RADIO_DRIVER_EXTENDED_SUPPORT */
